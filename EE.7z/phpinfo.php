<?php 

phpinfo() ;

?>